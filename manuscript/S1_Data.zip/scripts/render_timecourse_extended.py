"""Render Fig2A/B and the existing84-ms continuation as Fig2C from released tables."""
from pathlib import Path
import argparse
import os
import tempfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.text import Text
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
ARMS=[(0,0),(0,1),(1,0),(1,1)]
COLORS=['#737373','#E76F51','#2A9D8F','#195E56']
MARKERS=['o','s','^','D']
STYLES=[':','--','-.','-']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    frames=pd.read_csv(ROOT/'data/processed/frame_metrics.csv')
    endpoints=pd.read_csv(ROOT/'data/processed/run_endpoints.csv')
    extended=pd.read_csv(ROOT/'data/processed/extended_e1h1_timecourse.csv')
    assert sorted(extended.seed.unique())==[9310002,9310003,9310004]
    for _,part in extended.groupby('seed'):
        assert np.array_equal(part.simulation_step,np.arange(200,120001,200))
    original=frames.loc[frames.E.eq(1)&frames.H.eq(1),['seed','simulation_step','largest_component_fraction']]
    paired=original.merge(extended,on=['seed','simulation_step'],suffixes=('_original','_extended'))
    assert len(paired)==600
    assert np.allclose(paired.largest_component_fraction_original,
                       paired.largest_component_fraction_extended,rtol=0,atol=1e-12)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
        'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,
        'legend.fontsize':8,'pdf.fonttype':42,'ps.fonttype':42})
    fig=plt.figure(figsize=(7.5,7.0),layout='constrained')
    grid=fig.add_gridspec(2,2)
    axa=fig.add_subplot(grid[0,0]); axb=fig.add_subplot(grid[0,1])
    axc=fig.add_subplot(grid[1,:])
    series={}
    for (e,h),color,marker,style in zip(ARMS,COLORS,MARKERS,STYLES):
        group=frames.loc[frames.E.eq(e)&frames.H.eq(h)]
        summary=group.groupby('frame_index').agg(time=('time_ms','mean'),
            mean=('largest_component_fraction','mean'),sd=('largest_component_fraction','std'))
        series[e,h]=summary
        axa.plot(summary.time,summary['mean'],color=color,ls=style,lw=1.5,label=f'E{e}H{h}')
        axa.fill_between(summary.time,summary['mean']-summary.sd,
                         summary['mean']+summary.sd,color=color,alpha=.12)
        values=endpoints.loc[endpoints.E.eq(e)&endpoints.H.eq(h)]
        x=values.late_mean_synapsin_recruited_fraction
        y=values.late_mean_largest_component_vesicle_fraction
        axb.scatter(x,y,marker=marker,edgecolor=color,facecolor='white',s=31,zorder=4)
        axb.errorbar(x.mean(),y.mean(),xerr=x.std(ddof=1),yerr=y.std(ddof=1),
            marker=marker,color=color,markersize=5,capsize=3)
    reference=series[1,0]['mean']+series[0,1]['mean']-series[0,0]['mean']
    axa.plot(series[0,0].time,reference,color='black',ls=(0,(4,2)),lw=1,label='Additive reference')
    late_start=frames.loc[frames.frame_index.eq(140),'time_ms'].mean()
    axa.axvspan(late_start,28,color='gray',alpha=.08,zorder=0)
    axa.set(xlabel='Time (ms)',ylabel='Largest component / all agents',xlim=(0,28),ylim=(0,1))
    axa.legend(loc='upper left',frameon=False)
    axb.set(xlabel='Non-isolated Syn / all Syn',ylabel='SVs in largest component / all SVs',
            xlim=(.25,.95),ylim=(0,.8))
    for (seed,part),style in zip(extended.groupby('seed'),('-', '--', ':')):
        axc.plot(part.time_ms,part.largest_component_fraction,color='#737373',
            ls=style,lw=.85,alpha=.7,label=f'Seed {seed}',zorder=2)
    mean=extended.groupby('simulation_step').agg(time=('time_ms','mean'),
        fraction=('largest_component_fraction','mean'))
    axc.plot(mean.time,mean.fraction,color=COLORS[3],lw=1.65,label='Mean',zorder=3)
    axc.axvspan(0,28,color='#737373',alpha=.055,zorder=0)
    axc.axvline(28,color='#737373',ls='-.',lw=.85,zorder=1)
    axc.set(xlabel='Time (ms)',ylabel='Largest component / all agents',
            xlim=(0,84),ylim=(0,1),xticks=[0,14,28,42,56,70,84])
    axc.legend(loc='upper left',frameon=False,ncol=2)
    for ax,label in zip((axa,axb,axc),'ABC'):
        ax.spines[['top','right']].set_visible(False)
        ax.grid(axis='y',alpha=.15)
        ax.set_title(label,loc='left',fontweight='bold',fontsize=12)
    fig.canvas.draw()
    arial=Path('C:/Windows/Fonts/arial.ttf')
    if arial.exists():
        for item in fig.findobj(match=Text):
            file=Path('C:/Windows/Fonts/arialbd.ttf') if item.get_fontweight()=='bold' else arial
            item.set_fontproperties(font_manager.FontProperties(fname=str(file),size=item.get_fontsize()))
    args.output.mkdir(parents=True,exist_ok=True)
    for ext in ('pdf','png','tif'):
        target=args.output/f'force_factorial_timecourse.{ext}'
        fd,temp=tempfile.mkstemp(prefix='.figure2_',suffix='.'+ext,dir=args.output)
        os.close(fd)
        try:
            options={'dpi':600 if ext=='tif' else 180}
            if ext=='tif': options['pil_kwargs']={'compression':'tiff_lzw'}
            fig.savefig(temp,**options)
            os.replace(temp,target)
        finally:
            if os.path.exists(temp): os.unlink(temp)
    plt.close(fig)
    print('FIGURE2_ABC_COMPLETE primary_data_unchanged=True extension_rows=1800')

if __name__=='__main__':
    main()
