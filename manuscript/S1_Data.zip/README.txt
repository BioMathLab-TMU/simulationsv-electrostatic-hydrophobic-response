S1 Data: numerical inputs for the 12-run force study.
Frames/agents are nested, not independent replicates.
Historical column synapsin_recruited_fraction means non-isolated Syn fraction.
Interface and mobility diagnostics are post hoc; see audit JSON files.
Author-generated data: CC BY 4.0. Experimental values retain original terms.

Fig2C: extended_e1h1_timecourse.csv contains the same three E1H1 trajectories continued to 84 ms.
Original four-condition comparisons retain the common 28-ms horizon. These continuations are not additional independent replicates.
Reproduce Fig2A/B/C: python scripts/render_timecourse_extended.py --output figures
Rendering code: MIT (LICENSE); author-generated numerical data: CC BY 4.0 (DATA_LICENSE.md).

Detailed software-validation cases are in docs/ARTICLE_DIAGNOSTICS.md.
The four-condition comparison uses the common 28-ms observation period.
