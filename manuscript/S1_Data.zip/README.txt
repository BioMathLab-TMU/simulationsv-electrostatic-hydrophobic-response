Numerical data supporting the common-84-ms manuscript.
The current four-condition comparison uses 600 unique frames per trajectory.
Late structural values average the final 180 frames, 58.94--84 ms.
The common84ms subdirectory contains the current tables and all numerical figure inputs.
Earlier 28-ms tables are preserved in their original paths as a separate analysis.
They must not be mixed with the 84-ms summaries.
All fractions and contrasts retain full precision; three independent seed blocks are used.
The association shell remains 2 nm, with sensitivity checks at 0, 4 and 6 nm.
All native apparent-mobility fits use lags 2.10--3.92 ms.
Raw common-84-ms analysis-input HDF5 files are available from the article repository
under data/raw/common84ms, with hashes in data/common84ms_availability.json.
Original code is MIT-licensed; original generated data are CC BY 4.0.
Third-party materials retain their original licenses.
